canvas = document.getElementById('iControversy');
context = canvas.getContext('2d');



var goal = [];
var board = [];
var realGoal = [];


var boardPosition = 1;

var boardNumberGlobal = 0;
var goalNumberGlobal = 0;



var boardSize = canvas.width / 5;

var boardWallSize = (2 * boardSize / 25);

var initialWallSize = (canvas.width - (boardSize * boardNumberGlobal)) / 2 - (boardWallSize * (boardNumberGlobal - 1) / 2);

var gridSize = (boardSize / 3) - (boardSize / 30);
var wallSize = boardSize / 60;

var frameElapsed = 0;
var score = 0;

var level = 0;

var iteration = 0;

var setTime = 0;
var timeLeft = setTime;

var gameTimeLeft = (53 * canvas.width / 75) / setTime;
var timeBoxLeft = 53 * canvas.width / 75;

var count = 0;

var keyup = false;
var keydown = false;
var keyleft = false;
var keyright = false;

var narrativePicture = 0;


var gameLost = false;
var click = false;

var clickNumber = 0;

var mouseX = 0;
var mouseY = 0;

var numberg0 = new Image();
numberg0.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green0.png";
var numberg1 = new Image();
numberg1.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green1.png";
var numberg10 = new Image();
numberg10.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green10.png";
var numberg11 = new Image();
numberg11.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green11.png";
var numberg100 = new Image();
numberg100.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green100.png";
var numberg101 = new Image();
numberg101.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green101.png";
var numberg110 = new Image();
numberg110.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green110.png";
var numberg111 = new Image();
numberg111.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green111.png";
var numberg1000 = new Image();
numberg1000.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green1000.png";
var numberg1001 = new Image();
numberg1001.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green1001.png";
var numberg2 = new Image();
numberg2.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green2.png";
var numberg3 = new Image();
numberg3.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green3.png";
var numberg4 = new Image();
numberg4.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green4.png";
var numberg5 = new Image();
numberg5.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green5.png";
var numberg6 = new Image();
numberg6.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green6.png";
var numberg7 = new Image();
numberg7.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green7.png";
var numberg8 = new Image();
numberg8.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green8.png";
var numberg9 = new Image();
numberg9.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Green9.png";

var numberE = new Image();
numberE.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Empty.png";

var numbery0 = new Image();
numbery0.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow0.png";
var numbery1 = new Image();
numbery1.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow1.png";
var numbery10 = new Image();
numbery10.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow10.png";
var numbery11 = new Image();
numbery11.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow11.png";
var numbery100 = new Image();
numbery100.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow100.png";
var numbery101 = new Image();
numbery101.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow101.png";
var numbery110 = new Image();
numbery110.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow110.png";
var numbery111 = new Image();
numbery111.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow111.png";
var numbery1000 = new Image();
numbery1000.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow1000.png";
var numbery1001 = new Image();
numbery1001.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Yellow1001.png";

var numberb0 = new Image();
numberb0.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue0.png";
var numberb1 = new Image();
numberb1.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue1.png";
var numberb2 = new Image();
numberb2.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue2.png";
var numberb3 = new Image();
numberb3.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue3.png";
var numberb4 = new Image();
numberb4.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue4.png";
var numberb5 = new Image();
numberb5.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue5.png";
var numberb6 = new Image();
numberb6.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue6.png";
var numberb7 = new Image();
numberb7.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue7.png";
var numberb8 = new Image();
numberb8.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue8.png";
var numberb9 = new Image();
numberb9.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Number%20Tiles/Updated/Blue9.png";

var menu = new Image();
menu.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Concept%20Pictures/Title%20Screen.png"
var title1 = new Image();
title1.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Concept%20Pictures/Title.png"
var title2 = new Image();
title2.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Concept%20Pictures/Title2.png"
var title3 = new Image();
title3.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Concept%20Pictures/Title3.png"
var gameover = new Image();
gameover.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Concept%20Pictures/Gameover.png"
var tutorial = new Image();
tutorial.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Concept%20Pictures/Tutorial.png"

var nar1 = new Image();
nar1.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative1.jpg"
var nar2 = new Image();
nar2.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative2.jpg"
var nar3 = new Image();
nar3.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative3.jpg"
var nar4 = new Image();
nar4.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative4.jpg"
var nar5 = new Image();
nar5.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative5.jpg"
var nar6 = new Image();
nar6.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative6.jpg"
var nar7 = new Image();
nar7.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative7.jpg"
var nar8 = new Image();
nar8.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative8.jpg"
var nar9 = new Image();
nar9.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative9.jpg"
var nar10 = new Image();
nar10.src = "https://raw.githubusercontent.com/HiddenFat/iControversy/master/Narrative/narrative10.jpg"


function createBoard(boardNumber) {
  boardNumberGlobal = boardNumber;
  board = new Array(boardNumber);
  for (var i = 0; i < boardNumber; i++) {
    board[i] = new Array(3);
    for (var j = 0; j < 3; j++) {
      board[i][j] = new Array(3);
    }
    for (var j = 0; j < 3; j++) {
      for (var k = 0; k < 3; k++) {
        board[i][j][k] = 0;
      }
    }
  }
}

function createGoal(goalNumber) {
  goalNumberGlobal = goalNumber;
  goal = new Array(goalNumber);
  realGoal = new Array(goalNumber);
  for (var i = 0; i < goalNumber; i++) {
    var randomNumber = Math.floor((Math.random() * 10) + 1);
    goal[i] = randomNumber;
  }
}


function drawNextLevel(difficulty) {
  for (var i = 0; i < boardNumberGlobal; i++) {
    for (var j = 0; j < 3; j++) {
      for (var k = 0; k < 3; k++) {
        if (difficulty == 0) {
          console.log("difficulty :" + difficulty);
          if (Math.log2(board[0][j][k]) == realGoal[0] + 1) {
            context.fillStyle = "white";
            context.fillRect(100, 250, 200, 50);
            context.strokeStyle = "black";
            context.strokeRect(100, 250, 200, 50);
            context.stroke();
            context.font = "30px Calibri";
            context.fillStyle = "black";
            context.fillText("Next Level", 135, 285);
            if (mouseX < 300 && mouseX > 100 && mouseY > 250 && mouseY < 300) {
              console.log("success" + difficulty);
              level = 2;
              iteration = 0;
            }
          }
        } else if (difficulty == 1) {
          console.log("difficulty :" + difficulty);
          if (Math.log2(board[0][j][k]) == realGoal[0] + 1) {
            for (var x = 0; x < 3; x++) {
              for (var y = 0; y < 3; y++) {
                if (Math.log2(board[1][x][y]) == realGoal[1] + 1) {
                  for (var a = 0; a < 3; a++) {
                    for (var b = 0; b < 3; b++) {
                      if (Math.log2(board[2][a][b]) == realGoal[2] + 1) {
                        context.fillStyle = "white";
                        context.fillRect(100, 250, 200, 50);
                        context.strokeStyle = "black";
                        context.strokeRect(100, 250, 200, 50);
                        context.stroke();
                        context.font = "30px Calibri";
                        context.fillStyle = "black";
                        context.fillText("Next Level", 135, 285);
                        if (mouseX < 300 && mouseX > 100 && mouseY > 250 && mouseY < 300) {
                          console.log("success" + difficulty);
                          level = 3;
                          iteration = 0;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else if (difficulty == 2) {
          console.log("difficulty :" + difficulty);
          if (Math.log2(board[0][j][k]) == realGoal[0] + 1) {
            for (var x = 0; x < 3; x++) {
              for (var y = 0; y < 3; y++) {
                if (Math.log2(board[1][x][y]) == realGoal[1] + 1) {
                  for (var a = 0; a < 3; a++) {
                    for (var b = 0; b < 3; b++) {
                      if (Math.log2(board[2][a][b]) == realGoal[2] + 1) {
                        for (var u = 0; u < 3; u++) {
                          for (var v = 0; v < 3; v++) {
                            if (Math.log2(board[3][u][v]) == realGoal[3] + 1) {
                              context.fillStyle = "white";
                              context.fillRect(100, 250, 200, 50);
                              context.strokeStyle = "black";
                              context.strokeRect(100, 250, 200, 50);
                              context.stroke();
                              context.font = "30px Calibri";
                              context.fillStyle = "black";
                              context.fillText("Next Level", 135, 285);
                              if (mouseX < 300 && mouseX > 100 && mouseY > 250 && mouseY < 300) {
                                console.log("success" + difficulty);
                                level = 4;
                                iteration = 0;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else if (difficulty == 3) {
          console.log("difficulty :" + difficulty);
          if (Math.log2(board[0][j][k]) == realGoal[0] + 1) {
            context.fillStyle = "white";
            context.fillRect(100, 250, 200, 50);
            context.strokeStyle = "black";
            context.strokeRect(100, 250, 200, 50);
            context.stroke();
            context.font = "30px Calibri";
            context.fillStyle = "black";
            context.fillText("Next Level", 135, 285);
            if (mouseX < 300 && mouseX > 100 && mouseY > 250 && mouseY < 300) {
              console.log("success" + difficulty);
              level = 5;
              iteration = 0;
            }
          }
        }
      }
    }
  }
}




function setup(numGrid, time, difficulty) {
  if (iteration == 0) {
    initialWallSize = (canvas.width - (boardSize * numGrid)) / 2 - (boardWallSize * (numGrid - 1) / 2);
    createBoard(numGrid);
    createGoal(numGrid);
    spawnNumber();
    setTime = time;
    timeLeft = setTime;
    checkRealGoal(difficulty);
    mouseY = 0;
    mouseX = 0;
    gameTimeLeft = (53 * canvas.width / 75) / setTime;
    timeBoxLeft = 53 * canvas.width / 75;
    iteration = 1;
  }
  drawMenu();
  drawScore();
  drawTime();
}

function gameOver() {
  context.drawImage(gameover, 0, 0, canvas.width, canvas.height);
  alert("Game over! Restart?")
  level = 1;
  restart();
}

function restart() {
  level = level;
  iteration = 0;
}

function spawnNumber() {
  for (var i = 0; i < boardNumberGlobal; i++) {
    spawn(board[i]);
    spawn(board[i]);
  }
}

function drawMenu() {
  context.fillStyle = '#91C191';
  context.fillRect(0, 0, canvas.width, canvas.height); //draw background
  context.drawImage(title2, 23 * canvas.width / 150, -2 * canvas.height / 150, 2 * canvas.width / 3, 3 * canvas.height / 12);
}

function drawIntro() {
  if (clickNumber == 0) {
    context.drawImage(menu, 0, 0, canvas.width, canvas.height);
  }
}

function drawStory() {
  if (clickNumber == 1) {
    context.drawImage(nar1, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 2) {
    context.drawImage(nar2, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 3) {
    context.drawImage(nar3, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 4) {
    context.drawImage(nar4, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 5) {
    context.drawImage(nar5, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 6) {
    context.drawImage(nar6, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 7) {
    context.drawImage(nar7, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 8) {
    context.drawImage(nar8, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 9) {
    context.drawImage(nar9, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber == 10) {
    context.drawImage(nar10, 0, 0, canvas.width, canvas.height);
  }
}

function drawTutorial() {
  if (clickNumber == 11) {
    context.drawImage(tutorial, 0, 0, canvas.width, canvas.height);
  }
  if (clickNumber > 11) {
    level = level + 1;
  }
}

function drawGrid(xPosition, yPosition, boardLocation, boardArray, boardGoal) { //create gridboxes given position

  var goalNumber = boardGoal + 1;
  context.fillStyle = '#E8E7C4';
  context.fillRect(xPosition, yPosition, boardSize, boardSize); //outside box

  for (var i = 0; i < 3; i++) {
    for (var j = 0; j < 3; j++) {
      var a = ((gridSize + wallSize) * j) + (wallSize * 2);
      var b = ((gridSize + wallSize) * i) + (wallSize * 2);
      context.drawImage(numberE, a + xPosition, b + yPosition, gridSize, gridSize);
      var check = Math.log2(boardArray[i][j]);
      if (boardArray[i][j] > 0) {
        if (check == goalNumber && check == 2) {
          context.drawImage(numberg1, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 3) {
          context.drawImage(numberg2, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 4) {
          context.drawImage(numberg3, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 5) {
          context.drawImage(numberg4, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 6) {
          context.drawImage(numberg5, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 7) {
          context.drawImage(numberg6, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 8) {
          context.drawImage(numberg7, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 9) {
          context.drawImage(numberg8, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (check == goalNumber && check == 10) {
          context.drawImage(numberg9, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
        }
        if (boardPosition == boardLocation) {
          if (check == 1) {
            context.drawImage(numberg0, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 2) {
            context.drawImage(numberg1, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 3) {
            context.drawImage(numberg10, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 4) {
            context.drawImage(numberg11, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 5) {
            context.drawImage(numberg100, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 6) {
            context.drawImage(numberg101, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 7) {
            context.drawImage(numberg110, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 8) {
            context.drawImage(numberg111, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 9) {
            context.drawImage(numberg1000, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 10) {
            context.drawImage(numberg1001, a + xPosition, b + yPosition, gridSize, gridSize);
          }
        } else {
          if (check == 1) {
            context.drawImage(numbery0, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 2) {
            context.drawImage(numbery1, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 3) {
            context.drawImage(numbery10, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 4) {
            context.drawImage(numbery11, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 5) {
            context.drawImage(numbery100, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 6) {
            context.drawImage(numbery101, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 7) {
            context.drawImage(numbery110, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 8) {
            context.drawImage(numbery111, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 9) {
            context.drawImage(numbery1000, a + xPosition, b + yPosition, gridSize, gridSize);
          }
          if (check == 10) {
            context.drawImage(numbery1001, a + xPosition, b + yPosition, gridSize, gridSize);
          }
        }
      }
    }
  }
}

function changingGoal(xPosition, yPosition) {
  context.fillStyle = "#89CEC2"
  context.fillRect(xPosition + gridSize + (wallSize * 2), yPosition - (boardSize / 2), gridSize + wallSize + wallSize, gridSize + wallSize + wallSize);

  var goalNumber = Math.floor((Math.random() * 10) + 1);
  if (9.5 < goalNumber && goalNumber <= 10) {
    context.drawImage(numberb9, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (8.5 < goalNumber && goalNumber <= 9.5) {
    context.drawImage(numberb8, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (7.5 < goalNumber && goalNumber <= 8.5) {
    context.drawImage(numberb7, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (5.5 < goalNumber && goalNumber <= 7.5) {
    context.drawImage(numberb6, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (3.5 < goalNumber && goalNumber <= 5.5) {
    context.drawImage(numberb5, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (2.5 < goalNumber && goalNumber <= 3.5) {
    context.drawImage(numberb4, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (1.5 < goalNumber && goalNumber <= 2.5) {
    context.drawImage(numberb3, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else if (1 < goalNumber && goalNumber <= 1.5) {
    context.drawImage(numberb2, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  } else {
    context.drawImage(numberb1, xPosition + gridSize, yPosition + gridSize, gridSize, gridSize);
  }
}

function checkRealGoal(difficulty) {
  for (var i = 0; i < boardNumberGlobal; i++) {
    if (difficulty == 1) {
      if (8 < goal[i] && goal[i] <= 10) {
        realGoal[i] = 4;
      } else if (4 < goal[i] && goal[i] <= 8) {
        realGoal[i] = 3;
      } else if (0 < goal[i] && goal[i] <= 4) {
        realGoal[i] = 2;
      }
    } else if (difficulty == 2) {
      if (9.5 < goal[i] && goal[i] <= 10) {
        realGoal[i] = 7;
      } else if (8.5 < goal[i] && goal[i] <= 9.5) {
        realGoal[i] = 6;
      } else if (7.5 < goal[i] && goal[i] <= 8.5) {
        realGoal[i] = 5;
      } else if (5.5 < goal[i] && goal[i] <= 7.5) {
        realGoal[i] = 4;
      } else if (3.5 < goal[i] && goal[i] <= 5.5) {
        realGoal[i] = 3;
      } else {
        realGoal[i] = 2;
      }
    } else if (difficulty == 3) {
      realGoal[i] = 8;
    } else if (difficulty == 0) {
      realGoal[i] = 3;
    }
  }
}


function drawGoal(xPosition, yPosition, goal, difficulty) {
  context.fillStyle = "white"
  context.fillRect(xPosition + gridSize + (wallSize * 2), yPosition - (boardSize / 2), gridSize + wallSize + wallSize, gridSize + wallSize + wallSize);

  var goalNumber = goal;
  if (difficulty == 1) {
    if (8 < goalNumber && goalNumber <= 10) {
      context.drawImage(numberb4, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else if (4 < goalNumber && goalNumber <= 8) {
      context.drawImage(numberb3, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else if (0 < goalNumber && goalNumber <= 4) {
      context.drawImage(numberb2, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    }
  } else if (difficulty == 2) {
    if (9.5 < goalNumber && goalNumber <= 10) {
      context.drawImage(numberb7, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else if (8.5 < goalNumber && goalNumber <= 9.5) {
      context.drawImage(numberb6, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else if (7.5 < goalNumber && goalNumber <= 8.5) {
      context.drawImage(numberb5, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else if (5.5 < goalNumber && goalNumber <= 7.5) {
      context.drawImage(numberb4, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else if (3.5 < goalNumber && goalNumber <= 5.5) {
      context.drawImage(numberb3, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    } else {
      context.drawImage(numberb2, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
    }

  } else if (difficulty == 3) {
    context.drawImage(numberb8, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
  } else if (difficulty == 0) {
    context.drawImage(numberb3, xPosition + gridSize + (wallSize * 3), yPosition - (boardSize / 2) + wallSize, gridSize, gridSize);
  }
}

function drawTime() { //displays time limit

  if (timeLeft > 0) { //timer
    timeLeft = timeLeft - (1 / 30);
  } else {
    timeLeft = 0;
    gameLost = true;
  }

  if (timeBoxLeft <= 0) { // calculate box left with time
    timeBoxLeft = 0;
  } else {
    timeBoxLeft = timeBoxLeft - (gameTimeLeft / 30);
  }

  var min = Math.floor(timeLeft / 60); //calculate minute
  var sec = Math.round(timeLeft - (min * 60)); //calculate seconds

  context.fillStyle = "black";
  context.font = "25px Verdana";

  if (sec < 10) {
    context.fillText("Time Left: " + min + ":0" + sec, 29 * canvas.width / 75, 10 * canvas.height / 30); //if 1 digit, show 0 in front
  } else {
    context.fillText("Time Left: " + min + ":" + sec, 29 * canvas.width / 75, 10 * canvas.height / 30); //display time
  }

  context.fillStyle = "black";
  context.fillRect(2 * canvas.width / 15, 15 * canvas.height / 75, 11 * canvas.width / 15, canvas.height / 15); //outer box

  context.fillStyle = "red";
  context.fillRect(11 * canvas.width / 75, 16 * canvas.height / 75, timeBoxLeft, canvas.height / 25); //inner box
}

function drawScore() { //displays score

  context.fillStyle = "#E8E7C4";
  context.fillRect(3 * canvas.width / 4, 9 * canvas.height / 30, canvas.width / 6, canvas.height / 12); //box

  context.font = "30px Verdana";
  context.fillStyle = "#36AD99";
  context.fillText("Score", 119 * canvas.width / 150, 5 * canvas.height / 15);

  context.font = "25px Verdana";
  context.fillStyle = "black";
  context.fillText(score, 41 * canvas.width / 50, 112 * canvas.height / 300); //actual score
  context.fillStyle = "white";
  context.fillRect(750, 300, 150, 50);
  context.strokeStyle = "black";
  context.strokeRect(750, 300, 150, 50);
  context.stroke();

  context.font = "25px Verdana";
  context.fillStyle = "black";
  context.fillText("Restart", 780, 335);

  if (mouseX > 750 && mouseX < 950 && mouseY > 300 && mouseY < 350) {
    restart();
  }


}

canvas.addEventListener('mousedown', handleMouseDown);

function handleMouseDown(e) {
  click = true;
  clickNumber++;
}

function spawn(spawnBoard) {
  var emptyX = new Array();
  var emptyY = new Array();
  for (var j = 0; j < spawnBoard.length; j++) {
    for (var i = 0; i < spawnBoard[j].length; i++) {
      if (spawnBoard[j][i] == 0) {
        emptyX.push(i);
        emptyY.push(j);
      }
    }
  }
  var pos = Math.floor((Math.random() * (emptyX.length))); // get random number 0-3
  var x = emptyX[pos];
  var y = emptyY[pos];
  var randnum = Math.floor((Math.random() * 10) + 1); // get random number 1-11
  if (randnum <= 9) { //90% chance to get 2
    spawnBoard[y][x] = 2;
  } else {
    spawnBoard[y][x] = 4;
  }
}
canvas.addEventListener("click", clickcoordinates);

function clickcoordinates(eventParams) { //manage clicking and mouse position
  mouseX = eventParams.clientX - 10;
  mouseY = eventParams.clientY - 10;
}


window.addEventListener("keydown", checkKeyDown, false); //check key
window.addEventListener("keyup", checkKeyUp, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function checkKeyDown(key) { //check which key is pressed a = 65 d = 68

  if (key.keyCode == "68" && count == 0) {
    if (boardPosition > boardNumberGlobal - 1) {
      boardPosition = 0;
    }
    boardPosition += 1;
    count = 1;
    console.log(boardPosition);
  }

  if (key.keyCode == "65" && count == 0) {
    if (boardPosition < 2) {
      boardPosition = boardNumberGlobal + 1;
    }
    boardPosition -= 1;
    console.log(boardPosition);
    count = 1;
  }

  if (key.keyCode == "38" && count > 0) { //up key
    keyup = false;
  }
  if (key.keyCode == "38" && count == 0) {
    keyup = true;
    count = 1;
    keyinput();
  }


  if (key.keyCode == "40" && count > 0) { //down key
    keydown = false;
  }
  if (key.keyCode == "40" && count == 0) {
    keydown = true;
    count = 1;
    keyinput();
  }


  if (key.keyCode == "37" && count > 0) { //left key
    keyleft = false;
  }
  if (key.keyCode == "37" && count == 0) {
    keyleft = true;
    count = 1;
    keyinput();
  }


  if (key.keyCode == "39" && count > 0) { //right key
    keyright = false;
  }
  if (key.keyCode == "39" && count == 0) {
    keyright = true;
    count = 1;
    keyinput();
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function checkKeyUp(key) { //check if key is not pressed
  if (key.keyCode == "68") { //key up
    count = 0;
  }
  if (key.keyCode == "65") { //key up
    count = 0;
  }
  if (key.keyCode == "38") { //key up
    keyup = false;
    count = 0;
  }

  if (key.keyCode == "40") { //key up
    keydown = false;
    count = 0;
  }

  if (key.keyCode == "37") { //key up
    keyleft = false;
    count = 0;
  }

  if (key.keyCode == "39") { //key up
    keyright = false;
    count = 0;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function keyinput() { //check key input
  var y = 0;
  var x = 0;
  if (keyup) {
    y = -1; //up is y = -1
  } else {
    if (keydown) {
      y = 1; //down is y = 1
    } else {
      y = 0; //not pressed is y = 0
    }
  }

  if (keyleft) {
    x = -1; //left is x = -1
  } else {
    if (keyright) {
      x = 1; //right is x = 1
    } else {
      x = 0; //not pressed is x = 0
    }
  }
  if (boardPosition == 1) {
    var array = gameplay(y, x, true, 0); // start gameplay and give input values
    if (array != null) { // if array is not empty, spawn
      board[0] = array;
      spawn(board[0]);
    }
  } else if (boardPosition == 2) {
    var array2 = gameplay(y, x, true, 1); // start gameplay and give input values
    if (array2 != null) { // if array is not empty, spawn
      board[1] = array2;
      spawn(board[1]);
    }
  } else if (boardPosition == 3) {
    var array3 = gameplay(y, x, true, 2); // start gameplay and give input values
    if (array3 != null) { // if array is not empty, spawn
      board[2] = array3;
      spawn(board[2]);
    }
  } else if (boardPosition == 4) {
    var array4 = gameplay(y, x, true, 3); // start gameplay and give input values
    if (array4 != null) { // if array is not empty, spawn
      board[3] = array4;
      spawn(board[3]);
    }
  }



}


function gameplay(ydir, xdir, updatescore, number) { // for board 1
  var gridBoard = new Array(3);
  for (var i = 0; i < 3; i++) {
    gridBoard[i] = new Array(3);
  }
  for (var i = 0; i < 3; i++) {
    for (var j = 0; j < 3; j++) {
      gridBoard[i][j] = board[number][i][j]; //copy board to gridboard
    }
  } //copy board
  var moved = false;

  if (xdir != 0 || ydir != 0) {
    var d = 0;
    if (xdir != 0) {
      d = xdir;
    } else {
      d = ydir;
    }

    for (var prep = 0; prep < 3; prep++) //1
    {
      var a = 0;
      if (d > 0) {
        a = 2;
      } else {
        a = 1;
      }
      var b = 0;
      if (d > 0) {
        b = -1;
      } else {
        b = 3;
      }
      for (var tang = a; tang != b; tang -= d) //2
      {
        var y = 0;
        var x = 0;

        if (xdir != 0) {
          y = prep;
        } else {
          y = tang;
        }

        if (xdir != 0) {
          x = tang;
        } else {
          x = prep;
        }
        var targetx = x;
        var targety = y;
        if (gridBoard[y][x] == 0) {
          continue;
        }

        var c = 0;
        if (xdir != 0) {
          c = x;
        } else {
          c = y;
        }
        var aa = 0;
        if (d > 0) {
          aa = 3;
        } else {
          aa = -1;
        }
        for (var i = (c + d); i != aa; i += d) //3
        {
          var r = 0;
          var c = 0;
          if (xdir != 0) {
            r = y;
          } else {
            r = i;
          }
          if (xdir != 0) {
            c = i;
          } else {
            c = x;
          }
          if (gridBoard[r][c] != 0 && gridBoard[r][c] != board[number][y][x]) {
            break;
          }
          if (xdir != 0) {
            targetx = i;
          } else {
            targety = i;
          }
        } // x and y are now the block position, targetx and targety are where the block is sliding into loop 3 complete
        if ((xdir != 0 && targetx == x) || (ydir != 0 && targety == y)) {
          continue;
        } else if (gridBoard[targety][targetx] == board[number][y][x]) {
          gridBoard[targety][targetx] *= 2;
          if (updatescore) {
            score += gridBoard[targety][targetx];
          }
          moved = true;
        } else if ((xdir != 0 && targetx != x) || (ydir != 0 && targety != y)) {
          gridBoard[targety][targetx] = gridBoard[y][x];
          moved = true;
        }
        if (moved) {
          gridBoard[y][x] = 0;
        }

      }
    }
  }
  if (moved) {
    return gridBoard;
  } else {
    return null;
  }
}


function draw() {
  if (!gameLost) {

    if (level == 0) {
      drawIntro();
      drawStory();
      drawTutorial();
    }

    if (level == 1) {
      setup(1, 120, 0);
      context.font = "50px Calibri";
      context.fillStyle = "black";
      context.fillText("Level: " + level, 400, 300);
      context.font = "30px Calibri";
      context.fillText("Move the tiles with arrow keys.", 320, 350);
      context.fillText("Match the same numbers to create the next number.", 200, 380);
      context.fillText("<--- This is the goal number.", 550, 470);
      context.fillText("The numbers are in binary.", 60, 630);
      context.font = "25px Calibri";
      context.fillText("Try to reach the goal number.", 60, 670);

      drawGoal(initialWallSize, canvas.height - boardSize - boardWallSize, goal[0], 0);

      drawGrid(initialWallSize, canvas.height - boardSize - boardWallSize, 1, board[0], realGoal[0]);

      drawNextLevel(0);

    } else if (level == 2) {
      setup(3, 180, 1);
      context.font = "50px Calibri";
      context.fillStyle = "black";
      context.fillText("Level: " + level, 400, 300);
      context.font = "30px Calibri";
      context.fillText("Move between boards with A and D.", 300, 350);

      drawGoal(initialWallSize, canvas.height - boardSize - boardWallSize, goal[0], 1);
      drawGoal(boardSize + initialWallSize + boardWallSize, canvas.height - boardSize - boardWallSize, goal[1], 1);
      drawGoal((boardSize * 2) + (boardWallSize * 2) + initialWallSize, canvas.height - boardSize - boardWallSize, goal[2], 1);

      drawGrid(initialWallSize, canvas.height - boardSize - boardWallSize, 1, board[0], realGoal[0]);
      drawGrid(boardSize + initialWallSize + boardWallSize, canvas.height - boardSize - boardWallSize, 2, board[1], realGoal[1]);
      drawGrid((boardSize * 2) + (boardWallSize * 2) + initialWallSize, canvas.height - boardSize - boardWallSize, 3, board[2], realGoal[2]);

      drawNextLevel(1);
      /*     for(var i = 0; i < 3; i++){
      	for(var j = 0; j < 3; j++){
//        context.fillText("is ti working", 500, 400);
        	if(realGoal[0] == Math.log2(board[0][i][j])){
          	level++;
          	iteration = 0;
          }
        }
      }
      */

    } else if (level == 3) {
      setup(4, 300, 2);
      //      context.fillText(level, 400, 360);
      context.font = "50px Calibri";
      context.fillStyle = "black";
      context.fillText("Level: " + level, 400, 300);
      drawGoal(initialWallSize, canvas.height - boardSize - boardWallSize, goal[0], 2);
      drawGoal(boardSize + initialWallSize + boardWallSize, canvas.height - boardSize - boardWallSize, goal[1], 2);
      drawGoal((boardSize * 2) + (boardWallSize * 2) + initialWallSize, canvas.height - boardSize - boardWallSize, goal[2], 2);
      drawGoal((boardSize * 3) + (boardWallSize * 3) + initialWallSize, canvas.height - boardSize - boardWallSize, goal[3], 2);

      drawGrid(initialWallSize, canvas.height - boardSize - boardWallSize, 1, board[0], realGoal[0]);
      drawGrid(boardSize + initialWallSize + boardWallSize, canvas.height - boardSize - boardWallSize, 2, board[1], realGoal[1]);
      drawGrid((boardSize * 2) + (boardWallSize * 2) + initialWallSize, canvas.height - boardSize - boardWallSize, 3, board[2], realGoal[2]);
      drawGrid((boardSize * 3) + (boardWallSize * 3) + initialWallSize, canvas.height - boardSize - boardWallSize, 4, board[3], realGoal[3]);

      drawNextLevel(2);


    } else if (level == 4) {
      setup(1, 300, 3);
      context.font = "50px Calibri";
      context.fillStyle = "black";
      context.fillText("Level: " + level, 400, 300);
      drawGoal(initialWallSize, canvas.height - boardSize - boardWallSize, goal[0], 3);

      drawGrid(initialWallSize, canvas.height - boardSize - boardWallSize, 1, board[0], realGoal[0]);

      drawNextLevel(3);
    } else if (level == 5) {
      alert("Congratulations! You won!");
    }

  } else {
    gameOver();

  }
}

function game_loop() {
  draw();
}


setInterval(game_loop, 30);